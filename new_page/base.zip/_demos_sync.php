<?php
// Recibe el demos.json desde el dashboard de Taste (otro servidor) y lo guarda en disco.
//
//   POST  application/json   { "<slug>": { "API_KEY": "..." }, ... }   (la lista completa de demos)
//   X-Timestamp: <unix>      X-Signature: HMAC-SHA256( "<timestamp>.<cuerpo>", secreto )
//
// El secreto vive en demos.secret (una línea, junto a demos.json, no se sube al repo) y es el mismo
// DEMOS_SECRET del .env del dashboard. Sin firma válida no se escribe nada.

header('Content-Type: application/json; charset=utf-8');

function demos_sync_respond($status, $success, $message) {
    http_response_code($status);
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    demos_sync_respond(405, false, 'Método no permitido');
}

$dir = __DIR__;
$secretFile = $dir . '/demos.secret';
$secret = is_readable($secretFile) ? trim((string) file_get_contents($secretFile)) : '';
if ($secret === '') {
    demos_sync_respond(503, false, 'Falta demos.secret en el servidor');
}

$body = (string) file_get_contents('php://input');
$timestamp = (string) ($_SERVER['HTTP_X_TIMESTAMP'] ?? '');
$signature = (string) ($_SERVER['HTTP_X_SIGNATURE'] ?? '');

// Firma y vigencia (5 min): una foto vieja interceptada no se puede reenviar después
$expected = hash_hmac('sha256', $timestamp . '.' . $body, $secret);
if ($timestamp === '' || !ctype_digit($timestamp) || abs(time() - (int) $timestamp) > 300 || !hash_equals($expected, $signature)) {
    demos_sync_respond(403, false, 'Firma inválida');
}

$demos = json_decode($body, true);
if (!is_array($demos) || $demos === []) {
    demos_sync_respond(422, false, 'JSON inválido o vacío');
}
foreach ($demos as $slug => $entry) {
    if (!preg_match('/^[a-zA-Z0-9_-]{1,64}$/', (string) $slug) || !is_array($entry) || empty($entry['API_KEY']) || !is_string($entry['API_KEY'])) {
        demos_sync_respond(422, false, 'Entrada inválida: ' . $slug);
    }
}

// Se escribe a un temporal y se renombra: quien lea demos.json nunca ve un archivo a medias
$tmp = $dir . '/demos.json.' . bin2hex(random_bytes(6)) . '.tmp';
$json = json_encode($demos, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
if (@file_put_contents($tmp, $json . "\n", LOCK_EX) === false || !@rename($tmp, $dir . '/demos.json')) {
    @unlink($tmp);
    demos_sync_respond(500, false, 'No se pudo escribir demos.json (permisos de la carpeta)');
}

demos_sync_respond(200, true, count($demos) . ' demos guardadas');
