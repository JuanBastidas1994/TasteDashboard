<?php
// Utilidades compartidas por index.php y manifest.php.
// Un mismo build sirve a todas las marcas: aquí se decide de qué marca es la petición.

function taste_read_json($path) {
    if (!is_readable($path)) {
        return [];
    }
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : [];
}

/**
 * Config de la marca. Orden (el último pisa al anterior):
 *   config.defaults.json  -> valores compartidos (API_URL, GOOGLE_MAPS_API_KEY, ROLLBAR_*...)
 *   tenant.json           -> la marca de este dominio/carpeta ({"API_KEY": "..."} + overrides)
 *   demos.json[?m=slug]   -> demos: un solo dominio, varias marcas
 * Devuelve [config, slug_demo|null]. config vacío = marca no encontrada.
 */
function taste_tenant_config() {
    $dir = __DIR__;
    $config = taste_read_json($dir . '/config.defaults.json');
    $slug = null;

    $requested = $_GET['m'] ?? '';
    if ($requested !== '' && preg_match('/^[a-zA-Z0-9_-]{1,64}$/', $requested)) {
        $demos = taste_read_json($dir . '/demos.json');
        if (isset($demos[$requested]) && is_array($demos[$requested])) {
            $slug = $requested;
            return [array_merge($config, $demos[$requested]), $slug];
        }
    }

    $tenant = taste_read_json($dir . '/tenant.json');
    return [array_merge($config, $tenant), $slug];
}

/** GET /configuracion con caché en disco. Si el API falla se usa la última copia buena. */
function taste_fetch_business($apiUrl, $apiKey, $ttl = 300) {
    if ($apiUrl === '' || $apiKey === '') {
        return null;
    }
    $cacheDir = sys_get_temp_dir() . '/taste-cache';
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0755, true);
    }
    $cacheFile = $cacheDir . '/' . sha1($apiUrl . '|' . $apiKey) . '.json';

    if (is_readable($cacheFile) && (time() - filemtime($cacheFile)) < $ttl) {
        $cached = json_decode((string) file_get_contents($cacheFile), true);
        if (is_array($cached)) {
            return $cached;
        }
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 4,
            'ignore_errors' => true,
            'header' => "Api-Key: $apiKey\r\nAccept: application/json\r\n",
        ],
    ]);
    $body = @file_get_contents(rtrim($apiUrl, '/') . '/configuracion', false, $context);
    $json = $body !== false ? json_decode($body, true) : null;

    if (is_array($json) && ($json['success'] ?? 0) == 1 && !empty($json['informacion'])) {
        @file_put_contents($cacheFile, $body);
        return $json;
    }

    // API caída: mejor una copia vieja que una web sin marca
    if (is_readable($cacheFile)) {
        $stale = json_decode((string) file_get_contents($cacheFile), true);
        if (is_array($stale)) {
            return $stale;
        }
    }
    return null;
}

function taste_h($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
