<?php
// Punto de entrada. Toma el index.html compilado (idéntico para todas las marcas) y le inyecta
// título, metas para compartir (WhatsApp), favicon, manifest y la config de la marca.
require_once __DIR__ . '/_taste.php';

header('Content-Type: text/html; charset=utf-8');

$template = @file_get_contents(__DIR__ . '/index.html');
if ($template === false) {
    http_response_code(500);
    exit('Falta index.html (build).');
}

list($config, $demoSlug) = taste_tenant_config();
$apiUrl = (string) ($config['API_URL'] ?? '');
$apiKey = (string) ($config['API_KEY'] ?? '');

if ($apiKey === '') {
    http_response_code(404);
    exit('Marca no configurada.');
}

$business = taste_fetch_business($apiUrl, $apiKey);
$info = $business['informacion'] ?? [];

$title = (string) ($info['name'] ?? '');
$description = ($info['description'] ?? '') !== '' ? $info['description'] : $title;
$keywords = ($info['keywords'] ?? '') !== '' ? $info['keywords'] : $title;

// Imagen para compartir e íconos: URLs del dashboard (WhatsApp no ejecuta JavaScript, por eso van aquí)
$image = !empty($info['share_image']) ? $info['share_image'] : ($info['logo'] ?? '');
$favicon = (string) ($info['favicon'] ?? '');
$appleIcon = !empty($info['icon_192']) ? $info['icon_192'] : $favicon;

function taste_set_meta($html, $attr, $name, $content) {
    $tag = '<meta ' . $attr . '="' . $name . '" content="' . taste_h($content) . '"/>';
    $regex = '/<meta\s+' . $attr . '="' . preg_quote($name, '/') . '"[^>]*>/i';
    if (preg_match($regex, $html)) {
        return preg_replace($regex, str_replace('$', '\$', $tag), $html, 1);
    }
    return str_replace('</head>', "    $tag\n  </head>", $html);
}

$html = $template;
if ($title !== '') {
    $html = preg_replace('/<title>.*?<\/title>/is', '<title>' . str_replace('$', '\$', taste_h($title)) . '</title>', $html, 1);
    $html = taste_set_meta($html, 'name', 'description', $description);
    $html = taste_set_meta($html, 'name', 'keywords', $keywords);
    $html = taste_set_meta($html, 'property', 'og:title', $title);
    $html = taste_set_meta($html, 'property', 'og:description', $description);
    $html = taste_set_meta($html, 'name', 'twitter:title', $title);
    $html = taste_set_meta($html, 'name', 'twitter:description', $description);
}
if ($image !== '') {
    $html = taste_set_meta($html, 'property', 'og:image', $image);
    $html = taste_set_meta($html, 'property', 'og:image:secure_url', $image);
    $html = taste_set_meta($html, 'name', 'twitter:image', $image);
}
if ($demoSlug) {
    $html = taste_set_meta($html, 'name', 'robots', 'noindex, nofollow');
}

if ($favicon !== '') {
    $iconTag = '<link rel="icon" type="image/png" href="' . taste_h($favicon) . '" />';
    $html = preg_match('/<link\s+rel="icon"[^>]*>/i', $html)
        ? preg_replace('/<link\s+rel="icon"[^>]*>/i', str_replace('$', '\$', $iconTag), $html, 1)
        : str_replace('</head>', "    $iconTag\n  </head>", $html);
}
if ($appleIcon !== '') {
    $html = str_replace('</head>', '    <link rel="apple-touch-icon" href="' . taste_h($appleIcon) . '" />' . "\n  </head>", $html);
}

// Manifest dinámico (nombre y color de la marca)
$manifestHref = 'manifest.php' . ($demoSlug ? '?m=' . rawurlencode($demoSlug) : '');
$html = preg_replace('/<link\s+rel="manifest"[^>]*>/i', '<link rel="manifest" href="' . taste_h($manifestHref) . '">', $html, 1);

// Config en runtime. Debe ir antes del <script type="module">, por eso va al inicio del <head>.
$config['BUSINESS'] = $business;
$payload = json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
$script = '<script>window.__TASTE_CONFIG__=' . $payload . ';</script>';
$html = preg_replace('/<head>/i', "<head>\n    $script", $html, 1);

// Sin caché agresiva: el HTML cambia con la marca, los assets de /assets llevan hash.
header('Cache-Control: no-cache');
echo $html;
