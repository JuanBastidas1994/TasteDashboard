<?php
// Manifest PWA por marca (nombre y colores salen del API, no del build).
require_once __DIR__ . '/_taste.php';

header('Content-Type: application/manifest+json; charset=utf-8');

list($config, $demoSlug) = taste_tenant_config();
$business = taste_fetch_business((string) ($config['API_URL'] ?? ''), (string) ($config['API_KEY'] ?? ''));
$info = $business['informacion'] ?? [];

$name = !empty($info['name']) ? $info['name'] : 'Tienda en línea';
$color = '#' . ltrim((string) (!empty($info['color']) ? $info['color'] : '667940'), '#');
// Íconos que el dashboard genera del logo (fondo blanco y margen: sirven también como "maskable")
$icons = [];
foreach ([['icon_192', '192x192', 'any'], ['icon_512', '512x512', 'any'], ['icon_512', '512x512', 'maskable']] as list($key, $size, $purpose)) {
    if (!empty($info[$key])) {
        $icons[] = ['src' => $info[$key], 'sizes' => $size, 'type' => 'image/png', 'purpose' => $purpose];
    }
}

$suffix = $demoSlug ? '?m=' . rawurlencode($demoSlug) : '';

echo json_encode([
    'name' => $name,
    'short_name' => $name,
    'description' => $name,
    'icons' => $icons,
    'theme_color' => $color,
    'background_color' => $color,
    'display' => 'standalone',
    'scope' => './',
    'start_url' => './' . $suffix,
    'orientation' => 'portrait',
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
