<?php

// Captura los datos POST
$paymentData = $_POST;

var_dump($paymentData);
var_dump($_POST);

$id = isset($_POST['message_id']) ? $_POST['message_id'] : "";
$cres = isset($_POST['cres']) ? $_POST['cres'] : "";
$status = isset($_POST['transStatus']) ? $_POST['transStatus'] : "";

if($status == "Y"){
    echo "Pago correcto, Id: $id";
}else{
    echo "Pago incorrecto";
}

?>